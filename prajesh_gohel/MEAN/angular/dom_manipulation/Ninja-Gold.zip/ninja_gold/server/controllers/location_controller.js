module.exports = {
  control: function(req, res) {
    res.json({ message: "success" });
  }
}
